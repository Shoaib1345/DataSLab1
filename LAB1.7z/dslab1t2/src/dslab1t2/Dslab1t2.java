/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dslab1t2;

/**
 *
 * @author ESHOP
 */
public class Dslab1t2 {

   
    
    public static void main(String[] args) {
        System.out.println(" exercise 1");
       int arr[]=new int [6];
       arr[0]=12;
       arr[1]=24;
       arr[2]=36;
       arr[3]=48;
       arr[4]=60;
       
    
 
      for (int i=arr.length-1;i>0;i--){
         
          arr[i]=arr[i-1];
               
     } 
      arr[0]=6;
      
       for (int i=0;i<arr.length;i++){
        System.out.println("element at index "+i+": "+arr[i]); 
               
      } 
      System.out.println(" exercise 2"); 
  int arr1[]=new int [6];
       arr1[0]=100;
       arr1[1]=200;
       arr1[2]=300;
       arr1[3]=400;
       arr1[4]=500;
    int newelement=250;
   int position=2;
     for (int i=arr1.length-1;i>0;i--){
         
          arr1[i]=arr1[i-1];
               
     } 

   
   for (int i=arr1.length-1;i>position;i--){
         
          arr1[i]=arr1[i-1];
   }         
     arr1[position]=newelement;
     for (int i=0;i<arr1.length;i++){
        System.out.println("element at index "+i+": "+arr1[i]); 
               
      }
     System.out.println(" exercise 3"); 
  int arr2[]=new int [6];
       arr2[0]=3;
       arr2[1]=6;
       arr2[2]=9;
       arr2[3]=12;
       arr2[4]=15;
       int newele=18;
       arr2[arr2.length-1]=newele;
      for (int i=0;i<arr2.length;i++){
        System.out.println("element at index "+i+": "+arr2[i]); 
               
      }  
}
}


