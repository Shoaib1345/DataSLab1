/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package searchingarrays;

/**
 *
 * @author ESHOP
 */
public class Searchingarrays {

  
    public static void main(String[] args) {
        System.out.println("Exercise 1: ");
        int arr[]={13,26,39,52,65};
        int index=4;
        System.out.println("element at index "+index+":"+arr[index]);
        System.out.println("Exercise 2");
        int arr1[]={4,6,2,8,10};
        int element=8;
        for(int i=0;i<arr1.length;i++){
            if(arr1[i]==element){
                System.out.println("Element "+element+" found at index: "+i);
            }
        }
        System.out.println("Exercise 3");
      int[] arr3={11,22,33,44,55};
       int target=33;
       int left=0;
       int right=arr.length-1;
     
           
       while(left<=right){
             int midle=left+(right-left)/2;
       if(arr3[midle]==target){
           System.out.println("element foud at index : "+midle);
           break;
       }
       else if(arr3[midle]<target){
         left=midle+1;}
       else{
       right=midle-1;}
           }
           
       
           
    }
    
}
